import { Routes, RouterModule } from '@angular/router';

export const routes: Routes = [
    // otras rutas
    {path: '', // Ruta raíz (por defecto)
    loadComponent: () => import('./components/home/home.component').then(m => m.HomeComponent)}, // Carga HomeComponent aquí
    
    {path: 'contacto', loadComponent: () => import('./components/contacto/contacto.component').then(m => m.ContactoComponent)},	

];
